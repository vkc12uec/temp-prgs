

/*
 * input: 561 => output: Five Hundred Sixty One
input: 12340982 => Output: Twelve million three hundred  forty  thousand nine hundred eighty two
*/

#include <iostream>
using namespace std;

int main () {
}
